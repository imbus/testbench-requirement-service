from pathlib import Path

from testbench_requirement_service.readers.abstract_reader import AbstractRequirementReader
from testbench_requirement_service.utils.helpers import (
    get_project_root,
    import_class_from_file_path,
    import_class_from_module_str,
)


def get_reader_class_from_file_path(file_path: Path) -> AbstractRequirementReader:
    try:
        return import_class_from_file_path(file_path, subclass_from=AbstractRequirementReader)  # type: ignore
    except Exception as e:
        message = f"Failed to import custom RequirementReader class from '{file_path}'."
        raise ImportError(message) from e


def get_reader_class_from_module_str(
    reader_name: str, default_package: str = "testbench_requirement_service.readers"
) -> AbstractRequirementReader:
    try:
        if "." in reader_name:
            return import_class_from_module_str(  # type: ignore
                reader_name, subclass_from=AbstractRequirementReader
            )

        return import_class_from_module_str(  # type: ignore
            default_package,
            class_name=reader_name,
            subclass_from=AbstractRequirementReader,
        )
    except Exception as e:
        message = f"Failed to import custom RequirementReader class from '{reader_name}'."
        raise ImportError(message) from e


def get_requirement_reader_from_reader_class_str(reader_class: str) -> AbstractRequirementReader:
    reader_path = Path(reader_class)
    if reader_path.is_file():
        return get_reader_class_from_file_path(reader_path)
    local_file = Path(__file__).resolve().parent / reader_path
    if local_file.is_file():
        return get_reader_class_from_file_path(local_file)
    if not local_file.suffix and local_file.with_suffix(".py").is_file():
        return get_reader_class_from_file_path(local_file.with_suffix(".py"))
    relative_from_root = get_project_root() / reader_path
    if relative_from_root.is_file():
        return get_reader_class_from_file_path(relative_from_root)
    return get_reader_class_from_module_str(reader_class)


def get_requirement_reader(app) -> AbstractRequirementReader:
    if not getattr(app.ctx, "requirement_reader", None):
        requirement_reader_config = app.config.READER_CONFIG_PATH
        requirement_reader_class_str = app.config.READER_CLASS
        requirement_reader_class = get_requirement_reader_from_reader_class_str(
            requirement_reader_class_str
        )
        requirement_reader = requirement_reader_class(requirement_reader_config)  # type: ignore
        if not isinstance(requirement_reader, AbstractRequirementReader):
            raise ImportError(
                f"{requirement_reader_class} is no instance of AbstractRequirementReader!"
            )
        app.ctx.requirement_reader = requirement_reader
    return app.ctx.requirement_reader  # type: ignore
